#include<stdio.h>
int main(){
	int n;
	printf("------tim gia tri lon nhat va nho nhat trong mang-----\n");
	printf("xin moi nhap n=");
	scanf("%d",&n);
	int a[n];
	for(int i=0;i<n;i++){
		printf("\nxin moi nhap so mang a[%d]=",i);
		scanf("%d",&a[i]);
	}
	int max=a[0];
	int min=a[0];
	for( int i=0;i<n;i++){
		if(max<a[i]){ 
		    max=a[i];
	}
	     if(min>a[i]){
	     	min=a[i];
		 }
	}
		printf("so lon nhat max=%d \n",max);
		printf("so lon nhat min=%d ",min);
}
