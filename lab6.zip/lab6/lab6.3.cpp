#include<stdio.h>
void hoanVi(int *a,int *b){
	int temp;
	temp=*a;
	*a=*b;
	*b=temp;
}
int main(){
	int n;
	printf("\nxin moi nhap n:");
	scanf("%d",&n);
	int a[n];
	printf("\nxin moi nhap mang:");
	for(int i=0;i<n;i++){
		printf("\na[%d]",i);
		scanf("%d",&a[i]);
	}
	for(int i=0;i<n;i++){
		for(int j=i+1;j<n;j++){
			if(a[i]<a[j]){
				hoanVi(&a[i],&a[j]);
			}	
			}	
		}
		for(int i=0;i<n;i++){
			printf("Vi tri thu mang[%d] la : %d \n",i,a[i]);
		}
	}
