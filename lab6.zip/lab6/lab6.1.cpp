#include<stdio.h>
int main(){
	int n;
	printf("***** TRUNG BINH CAC SO CHIA HET CHO 3 LA******\n");
	printf("nhap so n=");
	scanf("%d",&n);
	int mang[n];
	for(int i=0;i<n;i++){
		printf("\nmang[%d]",+i);
		scanf("%d",&mang[i]);
	}
	float tong=0;
	float tb;
	float dem=0;
	for(int i=0;i<n;i++){
		if(mang[i]%3==0){
			printf("so %d la ",mang[i]);
			tong+=mang[i];
			dem++;
			
		}
	}
	      tb=(float)tong/dem;
	    printf("trung binh cac so chia het cho 3 =%f",tb);
}
