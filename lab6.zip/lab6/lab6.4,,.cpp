#include<stdio.h>
int main(){
	int a,b,tich[a][b];
	printf("nhap a=");
	scanf("%d",&a);
	printf("nhap b=");
	scanf("%d",&b);
	int mang[a][b];
	printf("\n nhap mang[%d][%d]\n",a,b);
	for(int i=0;i<a;i++){
		for(int j=0;j<b;j++){
			printf("xin moi nhap mang[%d ,%d]:",i+1,j+1);
			scanf("%d",&mang[i][j]);
		}
	}
	for(int i=0;i<a;i++){
		for(int j=0;j<b;j++){
			tich[i][j]=mang[i][j]*mang[i][j];
   }
}
    printf("Ma tran ban dau:\n");
    for (int i = 0; i < a; i++) {
        for (int j = 0; j < b; j++) {
            printf("%d ", mang[i][j]);
        }
        printf("\n");
    }

    printf("Ma tran binh phuong:\n");
    for (int i = 0; i < a; i++) {
        for (int j = 0; j < b; j++) {
            printf("%d ", tich[i][j]);
        }
        printf("\n");
    }
}
