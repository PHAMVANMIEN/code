#include<stdio.h>
#include<string.h>
    int n;
    char s[5][20];
    char t[100];
void nhap(){
	printf("nhap chuoi n:");	
    scanf("%d",&n);
	gets(s[n]);
	for(int i=0;i<n;i++){
		printf("\nnhap 5 chuoi bat ki :[%d]\n",i);
		gets(s[i]);
     }
}
void xuat(){
	for(int i=0;i<5;i++){
		printf("\n%s",s[i]);
	}
}
void sapXep(){
		for(int i=0;i<n-1;i++){
			for(int j=i+1;j<n;j++){
				if(strcmp(s[i],s[j])>0){
					strcpy(t,s[i]);
					strcpy(s[i],s[j]);
					strcpy(s[j],t);
				}
			}
		}
}
int main(){
	printf("xay dung chuong trinh sap xep theo chu cai\n");
	nhap();
	printf("xuat ra");
	xuat();
	printf("\nsap xep theo thu tu");
	sapXep();
	xuat();
	}
