#include<stdio.h>
#include<string.h>
#include <ctype.h>
int main(){
	char s[100];
    printf("Xin moi nhap vao chuoi: ");
    gets(s);
    int i = 0;
    int n = 0;
    int p = 0; 
    while(s[i++] != '\0') {
        if(s[i]=='a' || s[i]=='i' || s[i]=='e' ||s[i]=='u' ||s[i]=='o'){
            n++;
        }else{
            p++;
        }
    }
printf("Chuoi '%s' co chua: %d nguyen am va %d phu am.", s, n, p);
 printf("\nSo phu am: %d\n", p);
    return 0;
}

