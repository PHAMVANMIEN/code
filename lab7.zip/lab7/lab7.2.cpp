#include<stdio.h>
#include<string.h>
int main(){
char userSys[] = "admin";
int passSys = 12345;
char user[100];
int pass;
 printf("xin moi nhap vao username:");
 gets(userSys);
 printf("xin moi nhap vao passSys:");
 scanf("%d",&pass);
if(strcmp(userSys,"admin")==0  && pass == passSys){
    printf("dang nhap thanh cong");
}else{
    printf("dang nhap that bai");
}
}
