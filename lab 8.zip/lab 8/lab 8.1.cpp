#include<stdio.h>
#include<string.h>
#include<stdlib.h>
struct sinhVien{
	char mssv[50];
	char tenSV[50];
	char nganhHoc[50];
	float diemTB;
};
int main(){
	int n;
	printf("nhap so sinh vien n:");
	scanf("%d",&n);
	struct sinhVien sv[n];
	for(int i=0;i<n;i++){
		printf("mssv:");
		fflush(stdin);
		gets(sv[i].mssv);
		printf("ten sinh vien:");
		gets(sv[i].tenSV);
		printf("nganh hoc:");
		gets(sv[i].nganhHoc);
		printf("diem trung binh:");
		scanf("%f",&sv[i].diemTB);
	}
		printf("******xuat mang*****\n");
		for(int i=0;i<n;i++){
			printf("mssv:%s\n",sv[i].mssv);
			printf("ten sinh vien:%s\n",sv[i].tenSV);
			printf("nganh hoc:%s\n",sv[i].nganhHoc);
			printf("diem trung binh:%.1f\n",sv[i].diemTB);
		}
}
