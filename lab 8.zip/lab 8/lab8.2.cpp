#include<stdio.h>
#include<string.h>
#include<stdlib.h>
struct sinhVien{
	char mssv[50];
	char tenSV[50];
	char nganhHoc[50];
	float diemTB;
};
int main(){
	int n;
	printf("nhap so sinh vien n:");
	scanf("%d",&n);
    struct sinhVien sv[n];
    	for(int i=0;i<n;i++){
    		printf("mssv:");
    		fflush(stdin);
    		gets(sv[i].mssv);
    		printf("ten sinh vien:");
    		gets(sv[i].tenSV);
    		printf("nganh hoc:");
    		gets(sv[i].nganhHoc);
    		printf("nhap diem trung binh:");
    		scanf("%f",&sv[i].diemTB);
		}
		for(int i=0;i<n;i++)
		{
			for( int j=i+1;j<n;j++)
			{
				if(sv[i].diemTB > sv[j].diemTB)
				{
					struct sinhVien svtemp;
					svtemp = sv[i];
					sv[i]=sv[j];
					sv[j]=svtemp;
				}
			}
		}
		printf("--------xuat mang------\n");
		for(int i=0;i<n;i++){
			printf("\nma so sinh vien: %s",sv[i].mssv);
			printf("\nten sinh vien : %s",sv[i].tenSV);
			printf("\nnganh hoc: %s",sv[i].nganhHoc);
			printf("\nnhap diem trung binh: %f",sv[i].diemTB);
		}
}
