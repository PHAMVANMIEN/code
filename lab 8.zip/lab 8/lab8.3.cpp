#include<stdio.h>
#include<string.h>
#include<stdlib.h>
struct sinhVien {
	char mssv[10];
	char tensv[20];
	char nganh[30];
	float diemTB;
};
int main(){
	int n;
	printf (" nhap so sinh vien: ");
	scanf("%d",&n);
	struct sinhVien sv[n];
	for (int i=0;i<n;i++){
	printf("mssv:");
	fflush(stdin);
	gets(sv[i].mssv);
	printf("ten sv:");
	gets(sv[i].tensv);
	printf("nganh:");
	gets(sv[i].nganh);
	printf("diem tb:");
	scanf("%f",&sv[i].diemTB);
	}
	for(int i=0;i<n;i++){
		for(int j=i+1;j<n;j++){
			if(sv[i].diemTB>sv[j].diemTB){
				struct sinhVien svtemp;
				svtemp=sv[i];
				sv[i]=sv[j];
				sv[j]=svtemp;
			}
		}
	}
	char mssv[10];
	printf("tim kiem mssv:");
	fflush(stdin);
	gets(mssv);
	for(int i=0;i<n;i++){
		if(strcmp(sv[i].mssv,mssv)==0){
			printf("\nma so sinh vien: %s",sv[i].mssv);
			printf("\nten sinh vien : %s",sv[i].tensv);
			printf("\nnganh hoc: %s",sv[i].nganh);
			printf("\ndiem trung binh: %f",sv[i].diemTB);
		}
	}
}
